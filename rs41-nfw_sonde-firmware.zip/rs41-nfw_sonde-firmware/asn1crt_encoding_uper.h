#ifndef ASN1SCC_ASN1CRT_ENCODING_UPER_H_
#define ASN1SCC_ASN1CRT_ENCODING_UPER_H_

#include "asn1crt_encoding.h"

#ifdef  __cplusplus
extern "C" {
#endif





#ifdef  __cplusplus
}
#endif


#endif
